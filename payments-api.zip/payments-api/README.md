# payments-api: shared sample for the contract-first labs

A minimal Spring Boot 3 (Java 21, Maven) project. It builds and its one test passes, but it has no payments code yet. You add the OpenAPI contract and the code in the lab runbooks.

## Before the lab

You need JDK 21 and an internet connection (see RB-0). Nothing else: Maven downloads itself through the wrapper.

## Check that it builds

Open this folder in your editor, open a terminal in it, and run:

- Mac or Linux: `./mvnw test`
- Windows: `mvnw.cmd test`

The first run downloads Maven and the dependencies, which can take a few minutes. You want `BUILD SUCCESS` at the end.

- Mac or Linux, "permission denied": run `chmod +x mvnw` once.
- A failure about the Java version: run `java -version` and confirm it prints 21.

## What is in here

| Path | Purpose |
| --- | --- |
| `pom.xml` | Maven build. Spring Boot 3.5, web and validation starters. The OpenAPI generator is added in RB-1, Step 4. |
| `src/main/resources/openapi/` | Empty. You create `payments.yaml` here in RB-1, Step 2. |
| `src/main/java/com/example/payments/` | The application class. Your controller goes in `web/` in RB-1, Step 6. |
| `src/test/java/com/example/payments/` | The starting test. Your contract tests go here in RB-1, Step 7. |
| `requests.http` | Two ready-made requests for the REST Client extension (use after RB-1, Step 6). |

## Rules for the labs

- Generated code lands in `target/generated-sources/openapi`. Never edit it.
- Copilot comparison files go in `scratch/`, outside `src/`.
