package com.example.payments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentsApplicationTests {

  @Test
  void contextLoads() {
    // Passes when the Spring application starts. RB-1, Step 1 uses this as the "it builds" check.
  }
}
