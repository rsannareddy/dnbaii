# payments-ui (starter)

Angular starter for the DnB AI Training labs (RB-2 onward). It is a clean workspace
created with `ng new payments-ui --style=css --routing=false --ssr=false --skip-git`
(zoneless, Vitest), plus the OpenAPI generator tool and a `generate:api` script.

Tested: `npm install`, `ng test --no-watch` (2 tests pass) and `ng build` all succeed.

## Use
1. Put this folder next to `payments-api`, so the two projects sit side by side.
2. `npm install`
3. `npx ng test --no-watch` and `npx ng build` (both should pass before you change anything)
4. After you write `payments.yaml` in payments-api (RB-1): `npm run generate:api`
   (needs Java; the first run downloads the generator, which needs internet access).
5. Continue with RB-2, Step 3.

`generate:api` uses `ngVersion=22.0.0`. If your Angular major version differs, change it in `package.json`.
Never edit anything under `src/app/api`: it is overwritten each time you generate.
